setwd("C:/Users/it24101124/Desktop/lab4")
getwd()
branch_data<-read.table("Exercise.txt", header = TRUE, sep = ",")
fix(branch_data)
attach(branch_data)
sapply(branch_data, class)


boxplot(branch_data$Sales_X1, main = "Boxplot of sales", ylab = "Sales_X1")


class(branch_data$Advertising_X2)

five_num_summary <- fivenum(branch_data$Advertising_X2)
print("Five-number summary for Advertising_X2:")
print(five_num_summary)


advertising_IQR <- IQR(branch_data$Advertising_X2)
print("Interquartile Range (IQR) for Advertising_X2:")
print(advertising_IQR)
